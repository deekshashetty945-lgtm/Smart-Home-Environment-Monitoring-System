WEEK 2 - FIRMWARE DEVELOPMENT AND IMPLEMENTATION
Project: Timer Interrupt Based LED Controller

1. OVERVIEW
This project demonstrates a simple interrupt-driven firmware application.
A simulated timer generates a periodic interrupt and the interrupt service
routine toggles a simulated LED. Hardware registers are represented by
variables so that the program can be compiled on a normal computer.

2. MAIN FUNCTIONS
- GPIO_Init()  : Initializes the simulated LED GPIO.
- Timer_Init() : Initializes the simulated timer and interrupt flag.
- LED_Set()    : Sets the LED to ON or OFF.
- LED_Toggle() : Changes the current LED state.
- Timer_Tick() : Simulates one timer tick and detects timer overflow.
- Timer_ISR()  : Simulated timer interrupt service routine.
- System_Init(): Performs system initialization.
- main()       : Runs the firmware simulation.

3. HOW TO COMPILE
Using GCC:
    gcc timer_led_controller.c -o timer_led_controller

4. HOW TO RUN
Linux/macOS:
    ./timer_led_controller

Windows:
    timer_led_controller.exe

5. EXPECTED OUTPUT
The program prints the initialization messages and then toggles the LED
after every TIMER_PERIOD_TICKS timer ticks. The output should contain
alternating LED ON and LED OFF messages.

6. TESTING
The simulation runs for 5000 timer ticks with a timer period of 1000 ticks.
Therefore, the interrupt service routine is expected to execute five times.
The LED changes state each time the simulated interrupt occurs.

7. NOTE
This is a hardware-independent simulation. For deployment on a specific
microcontroller, the GPIO and timer variables/functions should be replaced
with the corresponding MCU register configuration and interrupt vector.
